I included this because I have to. I expect anyone downloading maps to already know this stuff....

Map by NoNimus
Youtube.com/c/NoNimbus
steamcommunity.com/id/nimsy

Powered by Cloud Faction

Steamcommunity.com/groups/cloudfaction

Place into the maps folder of your desired game.
defualt drag and drop it set up for counter strike source.

universal drap and drop
game/gamedir/maps/

i.e
garrysmod/garrysmod/maps/
teamfortess2/tf2/maps/
halflife2deathmatch/hl2mp/maps/